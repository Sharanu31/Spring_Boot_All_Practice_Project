package com.petadaption.Pet.Adoption.Platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetAdoptionPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetAdoptionPlatformApplication.class, args);
	}

}
