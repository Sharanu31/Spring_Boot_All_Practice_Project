package com.petadaption.Pet.Adoption.Platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetAdoptionPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
