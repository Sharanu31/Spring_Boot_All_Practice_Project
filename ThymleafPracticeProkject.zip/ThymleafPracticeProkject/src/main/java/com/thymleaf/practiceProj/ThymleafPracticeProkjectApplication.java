package com.thymleaf.practiceProj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymleafPracticeProkjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThymleafPracticeProkjectApplication.class, args);
	}

}
