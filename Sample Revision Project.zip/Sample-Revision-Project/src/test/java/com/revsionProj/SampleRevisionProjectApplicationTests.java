package com.revsionProj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleRevisionProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
