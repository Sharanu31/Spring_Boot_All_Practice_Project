package com.revsionProj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleRevisionProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleRevisionProjectApplication.class, args);
	}

}
