package com.travel.planner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelPlannerSpringBootProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelPlannerSpringBootProjectApplication.class, args);
	}

}
